package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

public class PorckerGame {

    private final CardStuck cardStuck = new CardStuck();

    /**
     * プレーヤーの手札
     */
    private List<Card> playerCards;

    /**
     * ゲーム開始
     */
    public void Begin() {
        //開始メッセージ
        Msg.showOpeningMsg();
        //ポーカー1ゲームの勝負開始のメッセージ
        Msg.showBeginGameMsg();
        //カードを5枚配る
        deliveryPlayerCard();

        //テスト
        /*playerCards.set(0, 0);
        playerCards.set(1, 2);
        playerCards.set(2, 16);
        playerCards.set(3, 33);
        playerCards.set(4, 48);*/

        //手持ちのカードを並び替える
        sortPlayerCard();

        //手持ちのカードを画面に表示する
        showPlayerCards();

        //チェンジするカードの入力受付
        List<Integer> changeCardIndexList = inputChangeCard();
        //カードを入れ替える
        changeCard((changeCardIndexList));

        //手持ちのカードを並び替える
        sortPlayerCard();

        //手持ちのカードを画面に表示する
        showPlayerCards();

        //役の名前の出力
        Hand hand = new Hand(playerCards);
        System.out.println(hand.get_handName());

    }


    /**
     * 手札にカードを5枚配る
     * カードを5枚配る
     */
    private void deliveryPlayerCard() {
        playerCards = cardStuck.takeCards(5);
    }

    /**
     * カードを並び替える
     */
    private void sortPlayerCard() {
        Collections.sort(playerCards);
    }

    /**
     * カードを出力する
     */
    private void showPlayerCards() {
        for (Card playerCard : playerCards) {
            //カードをs1～c13で出力
            System.out.print(playerCard.getDisplayString() + " ");
        }
        System.out.println();
        System.out.println();
    }

    /**
     * カードを入れ替える
     * エラーメッセージの表示
     * @return changeCardIndexList
     */
    private List<Integer> inputChangeCard() {
        List<Integer> changeCardIndexList = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        while (true) {
            //チェンジするカードの番号の入力依頼メッセージ
            Msg.showCardChangeMsg();
            String changeCardIndexString = "";
            //ユーザーに入力を促す
            try{
                changeCardIndexString = reader.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }


            // 0-5の文字以外があれば再入力
            if (!Pattern.compile("^[0-5]+$").matcher(changeCardIndexString).matches()) {
                // エラーメッセージの表示
                Msg.showChangeNumErrMsg();
                continue;
            }

            // 重複した数字があればエラー
            if (hasSameNumberError(changeCardIndexString)) {
                // エラーメッセージの表示
                Msg.showSameNumberErrMsg();
                continue;
            }

            // 0が入力されている場合
            if (changeCardIndexString.contains("0")) {
                // 0が入っているのに他の数字が入っている場合にはエラーとして再度入力を促す
                if (Pattern.compile("[1-5]+").matcher(changeCardIndexString).find()) {
                    // 変更しない場合には0のみを入力させるメッセージ
                    Msg.showZeroOnlyErrMsg();
                    continue;
                }
                // changeCardIndexListには何も入れずに終わる
                // →戻りのListは、Count = 0
                break;
            }

            for (int i = 1; i < 6; i++) {
                // 含まれていたらchangeCardIndexListに追加する。
                if (changeCardIndexString.contains(String.valueOf(i))) {
                    changeCardIndexList.add(i - 1);
                }
            }
            break;
        }
        return changeCardIndexList;
    }


    /**
     * 入力された値の重複チェック
     * @param target 入力された値
     * @return hasErr 文字列内に同じ数値(0-9)があればtrueを返す
     */
    private boolean hasSameNumberError(String target) {
        for (int i = 0; i < 10; i++) {
            if (charCount(target, (char) (i + '0')) > 1) {
                //エラーがあったらtrue
                return true;
            }
        }
        return false;
    }

    /**
     * 文字列内の指定文字をカウントする
     * @param str 対象文字列
     * @param checkChar カウント対象文字
     * @return カウント数
     */
    int charCount(String str, char checkChar) {
        int count = 0;
        for (char x : str.toCharArray()) {
            if (x == checkChar) {
                count++;
            }
        }
        return count;
    }

    /**
     * changeCardメソッド
     * @param changeCardIndex　入れ替え後のカードリスト
     */
    private void changeCard(List<Integer> changeCardIndex) {
        if (changeCardIndex.size() != 0) {
            //入力された数字に位置するカードを入れ替える
            for (int playerCardIndex : changeCardIndex) {
                Card newCard = cardStuck.takeCard();
                playerCards.set(playerCardIndex, newCard);
            }
        }
    }
}