package com.company;
import java.util.List;

public class Hand {

    /**
     * @return 役名称を取得
     */
    public String get_handName() {
        return _handName;
    }

    private final List<Card> _Cards;
    private int[] _sameNumberCardCountList;

    //フラグを用意する
    private boolean _isLoyalStraightFlash = false;
    private boolean _isStraightFlash = false;
    private boolean _isFourCard = false;
    private boolean _isFullHouse = false;
    private boolean _isFlash = false;
    private boolean _isStraight = false;
    private boolean _isThreeCard = false;
    private boolean _isTwoPair = false;
    private boolean _isOnePair = false;
    private boolean _isHighCard = false;

    private boolean _isLoyal = false;

    private String  _handName = "";

    /**
     * コンストラクタ
     * @param cards 役判定対象のカードリスト
     */
    public Hand(List<Card> cards) {
        _Cards = cards;
        countNumber();
        judge();
    }


    /**
     * 役を判定する
     */
    private void judge() {
        _isFlash = isFlash();
        _isStraight = isStraight();

        // フラッシュではなくストレートでもない場合の処理
        // フラッシュかストレートならペア系の役は発生しない
        if (!_isFlash && !_isStraight) {
            _isFourCard = isFourCard();
            _isThreeCard = isThreeCard();
            _isTwoPair = isTwoPair();
            _isOnePair = isOnePair();
        }

        // 複合役（フルハウスなど）の判定
        compositeHandJudge();

        //役名称の設定
        setHandName();
    }


    /**
     * 役フラグの状態から役名を設定する
     */
    private void setHandName() {

        // 役のフラグをチェックして役名を確定させる
        if (_isLoyalStraightFlash) {
            _handName = "ロイヤルストレートフラッシュ";
        } else if (_isStraightFlash) {
            _handName = "ストレートフラッシュ";
        } else if (_isFourCard) {
            _handName = "4カード";
        } else if (_isFullHouse) {
            _handName = "フルハウス";
        } else if (_isFlash) {
            _handName = "フラッシュ";
        }else if(_isStraight){
            _handName = "ストレート";
        } else if (_isThreeCard) {
            _handName = "3カード";
        } else if (_isTwoPair) {
            _handName = "2ペア";
        } else if (_isOnePair) {
            _handName = "1ペア";
        } else if(_isHighCard){
            _handName = "ハイカード";
        }else{
            _handName = "";
        }

    }

    /**
     * カードの番号(1~13)が同じ数を数えて
     * 枚数を入れる配列
     */
    private void countNumber() {
        //枚数を入れる配列の宣言と初期化
        _sameNumberCardCountList= new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
        for (Card card : _Cards) {
            //取ったカードを定数(13)で割った余りからカードの数字を求める
            int _cardsNumber = card.get_cardNumber();
            _sameNumberCardCountList[_cardsNumber - 1]++;
        }
    }


    /**
     * 4カードの判定
     * 同じ数字が4枚存在
     */
    private boolean isFourCard() {
        for (int cardNumber : _sameNumberCardCountList) {
            if (cardNumber == 4) {
                return true;
            }
        }
        return false;
    }


    /**
     * フラッシュの判定
     * 5枚すべてが同じマーク
     */
    private boolean isFlash() {
        int firstCardMarkNumber = _Cards.get(0).get_cardMark();
        for (int i = 1; i < _Cards.size(); i++) {
            //取ったカードが先のカードと同じマークかを判定
            if (firstCardMarkNumber != _Cards.get(i).get_cardMark()) {
                return false;
            }
        }
        return true;
    }


    /**
     * ストレート(5枚が連続した数字で構成される)の判定
     */
    private boolean isStraight() {
        int minNumber = -1;
        int maxNumber = -1;
        for (int i = 0; i < _sameNumberCardCountList.length; i++) {
            // 同じカード番号(1~13)の数をチェックして2枚以上となっている場合はストレートでない
            if (_sameNumberCardCountList[i] > 1) {
                return false;
            }
            if (_sameNumberCardCountList[i] == 1) {
                //iが1の場合、最大値を入れ続ける
                maxNumber = i;
                if (minNumber == -1) {
                    minNumber = i;
                }
            }
        }

        // 10-J-Q-K-A の組み合わせもストレートとして扱う
        // その場合Loyalフラグを設定
        if (_sameNumberCardCountList[9] == 1 && _sameNumberCardCountList[10] == 1
                && _sameNumberCardCountList[11] == 1 && _sameNumberCardCountList[12] == 1
                && _sameNumberCardCountList[0] == 1) {
            //_isLoyalフラグ
            _isLoyal = true;
            return true;
        }

        //最大値-最小値が4なら、5枚が連続で構成されている
        return maxNumber - minNumber == 4;
    }

    /**
     * 3カードの判定
     * 同じ数字が3枚存在
     */
    private boolean isThreeCard() {
        for (int cardNumber : _sameNumberCardCountList) {
            if (cardNumber == 3) {
                return true;
            }
        }
        return false;
    }

    /**
     * 2ペアの判定
     */
    private boolean isTwoPair() {

        //カウントアップした数が2の場合は2ペア
        return countPair() == 2;
    }

    /**
     * 1ペアの判定
     */
    private boolean isOnePair() {

        //カウントアップした数が1の場合は1ペア
        return countPair() == 1;

    }

    /**
     * ペア(2枚同じ数字)の数を数える
     * @return ペア数（0~2）
     */
    private int countPair(){
        int counter = 0;
        for (int cardNumber : _sameNumberCardCountList) {
            if (cardNumber == 2) {
                //iが2ならカウントアップする
                counter++;
            }
        }

        return  counter;
    }

    /**
     * 複合的な役（スリーカード＋ワンペア＝フルハウスなど）を判断し役フラグを設定する
     */
    private void compositeHandJudge(){

        //フルハウスの場合、スリーカードとワンペアのフラグを解除
        if (_isThreeCard && _isOnePair) {
            _isFullHouse = true;
            _isThreeCard = false;
            _isOnePair = false;
        }

        //ストレートでありフラッシュである場合、_isLoyalを使ってロイヤルストレートフラッシュかストレートフラッシュかを判定
        if (_isStraight && _isFlash) {
            if (_isLoyal) {
                _isLoyalStraightFlash = true;
            } else {
                _isStraightFlash = true;
            }
            //ストレート、フラッシュそれぞれのフラグを解除
            _isStraight = false;
            _isFlash = false;
        }

        //すべてのフラグがfalseの場合
        if (!_isLoyalStraightFlash && !_isStraightFlash && !_isFourCard
                && !_isFullHouse && !_isFlash && !_isStraight
                && !_isThreeCard && !_isTwoPair && !_isOnePair) {
            _isHighCard = true;
        }
    }
}


